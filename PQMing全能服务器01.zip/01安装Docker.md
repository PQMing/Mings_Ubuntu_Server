# Ubuntu 安装 Docker

**更新 apt 工具及索引，以支持 https 存储库**

sudo apt-get update
 
sudo apt-get install \
    ca-certificates \
    curl \
    gnupg \
    lsb-release
    
**添加 Docker 官方 GPG 密钥（用于签名/验证、加密/解密）**

curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

**设置 stable 版稳定存储库（区别于夜间版/测试版 nightly / test ）**

echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

**更新 apt 工具及索引，并安装 Docker**

sudo apt-get update

sudo apt-get install docker-ce docker-ce-cli containerd.io
 
**验证 Docker Engine 是否正确安装（显示 “Hello from Docker!” 即为成功安装）**

sudo docker run hello-world
