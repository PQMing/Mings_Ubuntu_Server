# 可选项：安装浏览器翻译插件
**安装划词翻译插件**
打开自带的火狐浏览器，点击菜单里的扩展和主题，搜索划词翻译，点击安装即可，在英文界面空白处右键，选择划词翻译-网页全文翻译即可

# 为 Docker 安装图形化操作界面 Portainer

**创建 Portainer Server 存储数据库的卷**

sudo docker volume create portainer_data
    
**下载并安装 Portainer Server 容器**

sudo docker run -d -p 8000:8000 -p 9443:9443 --name portainer \
    --restart=always \
    -v /var/run/docker.sock:/var/run/docker.sock \
    -v portainer_data:/data \
    portainer/portainer-ce:latest

**查看 Docker 容器状态（NAMES 标签出现 portainer/portainer-ce 则成功运行）**

sudo docker ps

**使用 Ubuntu 自带的火狐浏览器访问（https://127.0.0.1:9443/）**
**或使用局域网内另一台计算机/手机的浏览器访问（https://服务器的IP:9443/）**

**对 Portainer 初始设置**
设置用户名及密码（8位字符或数字），点击 Get Started，载入后点击 local 即可
