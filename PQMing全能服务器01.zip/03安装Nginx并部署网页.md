# 启用 Web 个人导航页

**将 nginx 文件夹解压至 /home/你自己的用户名/ 之下**

**下载 Nginx 镜像**

Portainer 点击 Images 镜像，docker.io 右侧填入 nginx，点击 Pull the image 下载镜像

**部署并运行 Nginx 容器（可以理解为把 Nginx 镜像作为小型虚拟机启动）**

点击 Containers 标签，点击 Add Container 启动容器，名称填入Nginx，docker.io 右侧填入 nginx:latest（Images 标签页 Tags 标签选项）。

Manual network port publishing 手动发布网口设置项，把本地80端口映射到容器80端口。

在Advanced container settings高级容器设置中，点击map additional volume 映射附加卷，点击绑定文件夹及可读写，本地文件夹填入 ~/nginx/ 容器文件夹填入 /usr/share/nginx/html

Restart policy 重启策略调整为 Always 永远自动启动。

最后点击 Deploy the container 部署容器

**使用 Ubuntu 自带的火狐浏览器访问（http://127.0.0.1）**
**或使用局域网内另一台计算机/手机的浏览器访问（http://服务器的IP）**

# 常见 HTML 语法规则（用于自定义导航页）

**标签成对出现，标签对中的第一个标签是开始标签，第二个标签是结束标签**
<标签>内容</标签>

<h1>这是标题标签</h1>
<p>这是段落标签</p>
<a href="https://www.pqming.com">这是链接标签，点击后跳转链接</a>

**4FC08D代表十六进制RGB颜色**
ctx.fillStyle = '#4FC08D';

**更多内容可访问 https://www.runoob.com/html/html-tutorial.html 学习**
