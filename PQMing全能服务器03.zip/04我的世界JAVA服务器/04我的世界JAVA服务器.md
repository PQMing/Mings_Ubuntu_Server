#我的世界 JAVA 版服务器 v1.18.1 （已修复Log4j漏洞）

**JAVA 版服务端下载地址**
https://www.minecraft.net/zh-hans/download/server

**在用户主目录新建 mcj 文件夹**
**将 server.jar 放至 ～/mcj 文件夹**
**安装 JAVA 依赖包，确认安装时输入 y 并回车**

sudo apt update ; sudo apt install openjdk-17-jdk

**打开终端，进入 mcj 文件夹，以最大 4GB 内存（10 人以内可以 2GB 内存运行）运行 MC 服务器，并启用新手宝箱**

cd ~/mcj ; sudo java -Xmx4G -jar server.jar --bonusChest

**确保 JAVA 有权限访问 mcj 文件夹**

sudo chown -R 1000:1000 ~/mcj

**更改 eula.txt 文件，同意用户协议**

eula=true

**更改 server.properties 文件，关闭正版验证**

online-mode=false

**启动服务器（每次联机前运行此命令即可，命令最后添加 空格 nogui 可以无窗口启动）**

cd ~/mcj ; java -Xmx4G -jar server.jar --bonusChest



#开机自启（可选，不建议开启，对服务器整体性能及功耗有较大影响）

**将压缩包内 mcj.sh 解压至 mcj 文件夹，并在终端内运行以下命令**

cd ~/mcj ; chmod +x ~/mcj/mcj.sh

**打开开始菜单里启动应用程序，添加并粘贴以下命令（替换用户名），并命名为 Java**

sh /home/用户名/mcj/mcj.sh


#外网访问
*JAVA版TCP端口转发：25565*
