#! /bin/bash

cd ~/mcj ; java -Xmx4G -jar server.jar --bonusChest
