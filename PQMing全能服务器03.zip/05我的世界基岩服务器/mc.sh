#! /bin/bash

cd mc ; LD_PRELOAD= ./bedrock_server
